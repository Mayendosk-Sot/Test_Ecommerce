const express = require('express');
const router = express.Router();

//creacion de rutas 
router.get('/', (req, res) => {
    res.render('Principal');
});

router.get('/form',  (req, res)=> {
    res.render('form');
});
router.get('/Compras', (req, res) => {
    res.render('Compras');
});

module.exports = router;